# 🚀 Telegram Auto Likes Bot

## 📌 Description
A Telegram bot that sends Free Fire likes automatically when a user selects a server and provides a UID.  
It also includes a broadcast feature so the developer **@DAOUD_VIP** can send messages to all users.

---

## 🔧 Requirements
- Python 3.9+
- Telegram Bot Token from [@BotFather](https://t.me/BotFather)
- Required libraries (see `requirements.txt`)

---

## 📥 Installation
```bash
pip install -r requirements.txt